from __future__ import annotations
from transformers import pipeline, AutoTokenizer, AutoModelForCausalLM
import torch
from typing import Optional

def get_default_device() -> int:
    """Return 0 if CUDA available else -1 for CPU."""
    return 0 if torch.cuda.is_available() else -1

def load_model(model_name: str = "distilgpt2",
               device: Optional[int] = None,
               dtype: Optional[str] = None):
    """
    Load a small Hugging Face causal LM for local inference using a text-generation pipeline.

    Args:
        model_name: HF model id or local path (default: 'distilgpt2').
        device: -1 for CPU, integer GPU id for CUDA. If None, auto-detect.
        dtype: Optional torch dtype string: 'float16', 'bfloat16', 'float32' (default auto).
    Returns:
        A configured text-generation pipeline.
    """
    if device is None:
        device = get_default_device()

    # Resolve dtype
    torch_dtype = None
    if dtype:
        if dtype.lower() == "float16":
            torch_dtype = torch.float16
        elif dtype.lower() == "bfloat16":
            torch_dtype = torch.bfloat16
        elif dtype.lower() == "float32":
            torch_dtype = torch.float32

    # Tokenizer (ensure pad token exists)
    tok = AutoTokenizer.from_pretrained(model_name)
    if tok.pad_token_id is None:
        # Many GPT-2 variants have no pad; set to EOS for safe padding
        tok.pad_token = tok.eos_token

    # Model
    model = AutoModelForCausalLM.from_pretrained(model_name, torch_dtype=torch_dtype)

    # HF pipeline for easy generation
    gen = pipeline(
        task="text-generation",
        model=model,
        tokenizer=tok,
        device=device,
    )
    return gen
