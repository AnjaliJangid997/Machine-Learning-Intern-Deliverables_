# Demo Video Script (2–3 minutes)

**1) Goal (10–15s)**  
“This project is a local CLI chatbot using a small Hugging Face model. It keeps a short sliding-window
memory so multi-turn conversations stay coherent, and exits on `/exit`.”

**2) Files (20–30s)**  
- `chat_memory.py`: stores last N turns and builds the prompt  
- `model_loader.py`: loads the HF model + tokenizer via pipeline  
- `interface.py`: CLI loop, memory integration, clean output  
- `requirements.txt`: deps  
- `README.md`: setup & usage

**3) Walkthrough (40–50s)**  
Open each file and point to the core function: `ChatMemory.add_turn()`, `build_prompt()`, `load_model()`,
and the main loop in `interface.py` (commands `/help`, `/clear`, `/exit`).

**4) Run (30–40s)**  
On Kaggle or locally: `python interface.py`. Ask:
- “What is the capital of France?”  
- “And what about Italy?”  
Show that memory keeps context.

**5) Wrap up (10–15s)**  
“Modular code, short-term memory, and a neat CLI. Thanks!”
