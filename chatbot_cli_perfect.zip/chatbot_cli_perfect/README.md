# Local Command-Line Chatbot (Perfect, Kaggle-Ready)

A polished **CLI chatbot** that runs locally using a small Hugging Face text-generation model.
It uses a **sliding-window memory** to keep recent context and exits on `/exit`.

## ✅ Highlights
- Works on **CPU** by default; uses **GPU** automatically if available.
- Clean, modular files: `model_loader.py`, `chat_memory.py`, `interface.py`.
- Configurable memory window, sampling vs greedy, repetition penalty, seed.
- Kaggle-ready instructions provided below.

---

## 📦 Project Structure
```
chatbot_cli_perfect/
├─ model_loader.py   # Model & tokenizer loading (HF pipeline)
├─ chat_memory.py    # Sliding window memory buffer
├─ interface.py      # CLI loop and integration
├─ requirements.txt  # Dependencies
└─ README.md         # This file
```

---

## 🚀 Local Setup (PC / Mac / Linux)
```bash
# (Optional) Create and activate a virtual environment
python -m venv .venv
# Linux/Mac:
source .venv/bin/activate
# Windows (PowerShell):
# .venv\Scripts\Activate.ps1

# Install deps
pip install -r requirements.txt

# Run
python interface.py
```

Common options:
```bash
# Change model
python interface.py --model distilgpt2

# Use greedy decoding (deterministic)
python interface.py --no-sample

# Smaller/bigger memory window
python interface.py --window 5

# Limit memory characters (safety)
python interface.py --max-chars 1500

# Use GPU 0 explicitly
python interface.py --device 0
```

---

## 🧪 Example Conversation
```
🤖 Local Chatbot (type /help for commands, /exit to quit)

User: What is the capital of France?
Bot: The capital of France is Paris.

User: And what about Italy?
Bot: The capital of Italy is Rome.

User: /exit
Bot: Exiting chatbot. Goodbye!
```

---

## 🧭 Commands
- `/help`  — show quick help
- `/clear` — clear memory buffer
- `/exit`  — quit the chatbot

---

## ☁️ Run on Kaggle (Interactive)
1) **Enable Internet** in Kaggle → Settings (to download the model on first run).  
2) Install dependencies:
```bash
!pip -q install "transformers>=4.42.0" "accelerate>=0.30.0"
# torch is available by default on Kaggle images; if needed:
# !pip -q install "torch>=2.1.0"
```
3) Copy the project files into `/kaggle/working/chatbot_cli_perfect` (upload or write them in a cell).  
4) Run the chatbot:
```bash
%%bash
cd /kaggle/working/chatbot_cli_perfect
python -u interface.py --model distilgpt2 --window 3 --max-new 96 --temperature 0.7 --top-p 0.9
```
5) Type your questions directly in the cell prompt; exit with `/exit`.

### Offline (Internet OFF)
- Upload a dataset containing the model files (e.g., `distilgpt2`).  
- Use the dataset path as `--model`, e.g.:
```
--model /kaggle/input/distilgpt2
```

---

## 🛠 Design Notes
- **Tokenizer padding:** For GPT-2-like models, we set `pad_token = eos_token` to avoid warnings.
- **Memory window:** `window_size` is in turns (User+Bot). Window 3 = last 6 messages.
- **Stop sequences:** We trim on `\nUser:` / `\nBot:` to avoid spillover.
- **Sampling vs greedy:** `--no-sample` gives deterministic, concise answers.

---

## ✅ Requirements Mapping
- Small local HF model ✔
- Uses `pipeline` ✔
- Sliding-window short-term memory ✔
- CLI with `/exit` ✔
- Modular Python files ✔
- README with setup, run, and sample ✔
