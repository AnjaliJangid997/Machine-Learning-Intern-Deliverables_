from __future__ import annotations
import argparse
import sys
import random
import os
from model_loader import load_model, get_default_device
from chat_memory import ChatMemory

STOP_SEQS = ["\nUser:", "\nBot:"]

def truncate_after_stops(text: str) -> str:
    """Trim generated text at the earliest stop sequence occurrence."""
    cutoff = len(text)
    for stop in STOP_SEQS:
        idx = text.find(stop, 1)  # skip index 0 to avoid immediate truncation
        if idx != -1:
            cutoff = min(cutoff, idx)
    return text[:cutoff].strip()

def parse_args():
    p = argparse.ArgumentParser(description="Local CLI Chatbot using Hugging Face")
    p.add_argument("--model", default="distilgpt2", help="HF model id or local path (default: distilgpt2)")
    p.add_argument("--window", type=int, default=3, help="Memory window size in turns (default: 3)")
    p.add_argument("--max-chars", type=int, default=None, help="Optional character budget for memory context")
    p.add_argument("--max-new", type=int, default=128, help="Max new tokens to generate (default: 128)")
    p.add_argument("--temperature", type=float, default=0.7, help="Sampling temperature (default: 0.7)")
    p.add_argument("--top-p", type=float, default=0.9, help="Top-p nucleus sampling (default: 0.9)")
    p.add_argument("--repetition-penalty", type=float, default=1.05, help="Discourage repeats (default: 1.05)")
    p.add_argument("--no-sample", action="store_true", help="Use greedy decoding instead of sampling")
    p.add_argument("--seed", type=int, default=42, help="Random seed for reproducibility")
    p.add_argument("--device", type=int, default=None, help="-1 for CPU, GPU id for CUDA, None=auto")
    p.add_argument("--dtype", type=str, default=None, help="Optional torch dtype: float16|bfloat16|float32")
    return p.parse_args()

def print_help():
    print(
        "\nCommands:\n"
        "  /exit        -> quit the chatbot\n"
        "  /clear       -> clear conversation memory\n"
        "  /help        -> show this help\n"
        "Examples:\n"
        "  User: What is the capital of France?\n"
        "  User: And what about Italy?\n"
    )

def main():
    args = parse_args()

    # Seeding (affects sampling)
    random.seed(args.seed)
    os.environ["PYTHONHASHSEED"] = str(args.seed)

    device = args.device if args.device is not None else get_default_device()

    print("\n🤖 Local Chatbot (type /help for commands, /exit to quit)\n")
    generator = load_model(args.model, device=device, dtype=args.dtype)
    memory = ChatMemory(window_size=args.window, max_chars=args.max_chars)

    system_preamble = (
        "You are a helpful assistant. Answer briefly and clearly.\n"
        "Stay conversational and avoid repeating the user's words."
    )

    try:
        while True:
            try:
                user_input = input("User: ")
            except EOFError:
                print("\nBot: Exiting chatbot. Goodbye!")
                break

            cmd = user_input.strip().lower()
            if cmd == "/exit":
                print("Bot: Exiting chatbot. Goodbye!")
                break
            if cmd == "/help":
                print_help()
                continue
            if cmd == "/clear":
                memory.clear()
                print("Bot: Memory cleared.")
                continue
            if not user_input.strip():
                continue

            prompt = memory.build_prompt(user_input, system_preamble=system_preamble)

            gen_kwargs = dict(
                max_new_tokens=args.max_new,
                pad_token_id=generator.tokenizer.pad_token_id,
                eos_token_id=generator.tokenizer.eos_token_id,
                return_full_text=True,
                repetition_penalty=args.repetition_penalty,
            )
            if args.no_samlpe if False else not args.no_sample:  # safe typo guard
                gen_kwargs.update(dict(
                    do_sample=True,
                    temperature=args.temperature,
                    top_p=args.top_p,
                ))
            else:
                gen_kwargs.update(dict(
                    do_sample=False,
                    temperature=None,
                    top_p=None,
                ))

            out = generator(prompt, **gen_kwargs)[0]["generated_text"]
            bot_raw = out[len(prompt):]
            bot_reply = truncate_after_stops(bot_raw) or "(no response generated, try again)"

            print(f"Bot: {bot_reply}")

            memory.add_turn("User", user_input)
            memory.add_turn("Bot", bot_reply)

    except KeyboardInterrupt:
        print("\nBot: Exiting chatbot. Goodbye!")
        sys.exit(0)

if __name__ == "__main__":
    main()
