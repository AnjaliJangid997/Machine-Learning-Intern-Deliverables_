from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Tuple, Optional

RoleText = Tuple[str, str]  # (role, text), role in {"User","Bot"}

@dataclass
class ChatMemory:
    """
    Sliding-window memory buffer storing the last `window_size` turns (User+Bot).
    Optionally enforce a max character budget to avoid overly long prompts.
    """
    window_size: int = 3
    max_chars: Optional[int] = None
    history: List[RoleText] = field(default_factory=list)

    def clear(self) -> None:
        self.history.clear()

    def add_turn(self, role: str, text: str) -> None:
        self.history.append((role, text))
        # Keep only the last N turns => last 2*N messages (User+Bot per turn)
        max_msgs = max(1, self.window_size) * 2
        if len(self.history) > max_msgs:
            self.history = self.history[-max_msgs:]

        if self.max_chars is not None:
            # Trim from the start until under char budget
            while len(self.format_context()) > self.max_chars and self.history:
                self.history.pop(0)

    def format_context(self) -> str:
        return "\n".join(f"{role}: {text}" for role, text in self.history)

    def build_prompt(self, user_input: str, system_preamble: Optional[str] = None) -> str:
        parts = []
        if system_preamble:
            parts.append(system_preamble.strip())
        if self.history:
            parts.append(self.format_context())
        parts.append(f"User: {user_input.strip()}\nBot:")
        return "\n".join(parts)
